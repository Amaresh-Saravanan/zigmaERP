<?php
	die(':)');